var express    =require("express"),
    app        =express(),
    bodyparser =require("body-parser"),
    mongoose   =require("mongoose")
    
mongoose.connect("mongodb://localhost/yelp_camp");
app.use(bodyparser.urlencoded({extended:true}));
app.set("view engine","ejs");


// add a campground Schema
var campgroundSchema =new mongoose.Schema({
    name: String,
    img: String,
    desc:String
})
// add the campground model

var campground =mongoose.model("campground",campgroundSchema);

// create a new campground data and save it to the DB
// campground.create({
    
//     name:"Yellowstone Canyon",
//     img:"https://www.campsitephotos.com/photo/camp/69381/feature_Canyon-f3.jpg",
//     desc:"this is a beautiful campground of all times"
    
// }
// // the callback function
// ,function(err,newCreated){
//     if(err){
//         console.log(err);
//     }
//     else{
//         console.log("new campGround added :");
//         console.log(newCreated);
        
//     }
// }

// )



//  var campground=[{name:"Yuba Lake State Park Oasis",img:"https://www.campsitephotos.com/photo/camp/31448/feature_Oasis-f4.jpg"},
//     {name:"Yellowstone Canyon",img:"https://www.campsitephotos.com/photo/camp/69381/feature_Canyon-f3.jpg"},
//     {name:"Windwhistle",img:"https://www.campsitephotos.com/photo/camp/16039/feature_Windwhistle-f3.jpg"}
//     ];


// landing route----------------
app.get("/",function(req,res){
   res.render("landing"); 
});


//  campgounds GET route-------------
app.get("/campgrounds",function(req,res){
   
     campground.find({},
     function(err,allCampgrounds){
         if(err){
             console.log(err);
         }
         else{
            res.render("campgrounds",{campground:allCampgrounds});
         }
     });
});
//  campgounds POST route-------------
app.post("/campgrounds",function(req,res){
    var name=req.body.name;
    var img=req.body.img;
    var newcampground={name:name,img:img};
    campground.create(newcampground,function(err,newAdded){
        if(err){
            console.log(err);
        }
        else{
            res.redirect("/campgrounds");
        }
    })
  
});

app.get("/campgrounds/new",function(req,res){
   res.render("new.ejs"); 
});

app.get("/campgrounds/:id",function(req,res){
    res.send("this is a show page ");
})







app.listen(process.env.PORT,process.env.IP,function(req,res){
   console.log("server started!!"); 
});