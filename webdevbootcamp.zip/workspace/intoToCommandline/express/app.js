var express=require("express");
var app=express();

app.get("/",function(req,res){
   res.send("Hello from the server side!") 
});

app.get("/dog",function(req,res){
   res.send("WOOF!!") 
});

app.get("/bye",function(req,res){
   res.send("GOODBYE!") 
});





app.listen(process.env.PORT,process.env.IP,function(){
    console.log("server has started!!!");
});
    
