var express=require("express");
var app=express();

app.use(express.static("public"));
app.set("view engine","ejs");

app.get("/",function(req,res){
   res.render("home"); 
});

app.get("/shitty/:thing",function(req,res){
    var thing=req.params.thing;
   res.render("shit",{thingVar:thing}); 
});

app.get("/posts",function(req,res){
    var posts=[{title:"Angery posts only",author:"angry"},
    {title:"عسكري جه يعمر البندقيه لقاها حمصية",author:"kon badeen"},
    {title:"No post to see here",author:"invisible"}];
    
    res.render("posts",{posts:posts});
});
app.get("*",function(req,res){
   res.send("wait a minute, F U"); 
});

app.listen(process.env.PORT,process.env.IP,function(){
   console.log("the server is up!"); 
});