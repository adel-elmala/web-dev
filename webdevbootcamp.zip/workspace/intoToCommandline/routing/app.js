var express=require("express");
var app=express();
var animals={
    pig:"oink",
    dog:"WOOF",
    cat:"MEAW",
    cow:"MOO",
    lion:"ROAR"
};

app.get("/",function(req,res){
    res.send("Hi There!,Welcome to my assignment");
});

app.get("/speak/:animal",function(req,res){
    var animal=req.params.animal;
    var sounds=animals[animal];
   res.send("THE "+ animal.toUpperCase() +" says "+ sounds)
   
   
});
app.get("/repeat/:string/:num",function(req,res){
   var stringTorepeat=req.params.string;
   var numTorepeat=req.params.num;
   var output=""
   for(var i=0;i<numTorepeat;i++){
      output +=" "+stringTorepeat;
   }
   res.send(output);
});

app.get("*",function(req,res){
   res.send("Sorry,Page NOT found ...WHAT ARE YOU DOING WITH YOUR LIFE?");
  
});
app.listen(process.env.PORT,process.env.IP,function(){
        console.log("SERVER has STARTED!");

});