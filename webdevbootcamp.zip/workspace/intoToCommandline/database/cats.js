var mongoose =require("mongoose");
mongoose.connect("mongodb://localhost/cat_app");
var catSchema = new mongoose.Schema({
  name: String,
  age: Number,
  reputation: String
});

var Cat=mongoose.model("Cat",catSchema);

var fresca =new Cat({
    name:"fresca",
    age:1,
    reputation:"always hungery"
});

fresca.save(function(err,Cat){
    if(err){
        console.log("ERROE!");
    }
    else{
        console.log("just saved:");
        console.log(Cat);
    }
})