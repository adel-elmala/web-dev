var faker = require('faker');

    var randomProductName=faker.commerce.productName();
    var randomPrice=faker.commerce.price();
    var randomNumber=faker.random.number();

console.log("==========================================");
console.log("WELCOME TO MYSHOP");
console.log("==========================================");
for(var i=0;i<6;i++){
     randomProductName=faker.commerce.productName();
     randomPrice=faker.commerce.price();

    var listItem=randomProductName+"- $"+randomPrice;
    console.log(listItem);
}