var score=[90,98,89,100,100,86,94];
var score2=[40,65,77,82,80,54,73,63,95,49];
function avrage(arr){
    var total=0;
    for(var i=0;i<arr.length;i++){
        total+=arr[i];
        
    }
    var avragenum=total/arr.length;
    return Math.round(avragenum);
    
}

avrage(score2);